* Evaluate to extend ``FILES_TO_CACHE``
* Evaluate to use a normal JS file for service worker and download data from a normal JSON controller
* Integrate `Notification API <https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration/showNotification>`_
* Integrate `Web Share API <https://web.dev/web-share/>`_
* Create ``portal_pwa`` module, intended to be used by front-end users (customers, suppliers...)
